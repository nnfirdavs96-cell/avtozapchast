/* eslint-disable */
/* GARAGE — extra screens: catalog, part page, cart, checkout, search/VIN,
   login, orders, manager dashboard, mobile */

const gs = window.garageStyles;
const GLabel = window.GarageLabel;
const GBadge = window.GarageBadge;
const GHeader = window.GarageHeader;
const GIcon = window.GaragePartIcon;
const GPlate = window.GaragePlate;
const GBtn = window.GarageBtn;
const GGrid = window.GarageGrid;
const GCard = window.GaragePartCard;

// ════════════════════════════════════════════════════════════
// GARAGE Catalog
// ════════════════════════════════════════════════════════════
function GarageCatalog({ lang, setLang, density }) {
  const { T, BRANDS, PARTS, fmt } = window.AVTO_DATA;
  const t = T[lang]; const f = fmt(lang);
  const sortOpts = [t.sort_newest, t.sort_price_asc, t.sort_price_desc, t.sort_popular, t.sort_rating];
  return (
    <div className="ab" style={{ background: gs.bg, color: gs.text, fontFamily: gs.body, minHeight: '100%' }}>
      <GHeader t={t} lang={lang} setLang={setLang} density={density}/>

      {/* breadcrumb + heading */}
      <div style={{ padding: '24px 64px 8px' }}>
        <div style={{ display: 'flex', gap: 8, fontFamily: gs.mono, fontSize: 11, color: gs.mute }}>
          <span>{lang==='ru'?'Главная':'Bosh sahifa'}</span><span>/</span>
          <span>{t.catalog}</span><span>/</span>
          <span style={{ color: gs.accent }}>{t.categories[0][0].toUpperCase()}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 16, marginTop: 14 }}>
          <h1 style={{ fontFamily: gs.display, fontSize: 64, letterSpacing: '3px', margin: 0 }}>
            {t.categories[0][0].toUpperCase()}
          </h1>
          <GLabel style={{ fontSize: 11 }}>1 240 SKU · 14 BRANDS · {t.in_stock.toUpperCase()}</GLabel>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 24, padding: '20px 64px 64px' }}>
        {/* sidebar */}
        <aside style={{ background: gs.bg2, border: `1px solid ${gs.line}`, padding: 18, height: 'fit-content' }}>
          <FilterSection title={t.filters} dense>
            {[t.in_stock, t.delivery_24h, 'OEM', lang==='ru'?'Аналоги':'Analoglar', lang==='ru'?'Со скидкой':'Chegirma bilan'].map((v,i) => (
              <CheckRow key={i} label={v} count={[1240, 980, 642, 598, 312][i]} on={i===0||i===2}/>
            ))}
          </FilterSection>

          <FilterSection title={lang==='ru'?'Бренд':'Brend'}>
            {BRANDS.slice(0, 7).map((b, i) => (
              <CheckRow key={b.name} label={`${b.name}`} count={[124, 87, 56, 42, 38, 28, 21][i]} on={i<2}/>
            ))}
            <div style={{ fontFamily: gs.mono, fontSize: 10, color: gs.accent, marginTop: 8, cursor: 'pointer' }}>
              + {lang==='ru'?'ПОКАЗАТЬ ВСЕ':"HAMMASINI KO'RSATISH"}
            </div>
          </FilterSection>

          <FilterSection title={`${t.price} (${lang==='ru'?'₽':"so'm"})`}>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              <FilterInput v="60 000" l={t.from}/>
              <span style={{ color: gs.mute }}>—</span>
              <FilterInput v="2 100 000" l={t.to}/>
            </div>
            <div style={{ marginTop: 12, height: 4, background: gs.line, position: 'relative', borderRadius: 2 }}>
              <div style={{ position: 'absolute', left: '8%', right: '32%', top: 0, bottom: 0, background: gs.accent }}/>
              <div style={{ position: 'absolute', left: '8%', top: -4, width: 12, height: 12, background: '#000', border: `2px solid ${gs.accent}`, borderRadius: '50%' }}/>
              <div style={{ position: 'absolute', left: '68%', top: -4, width: 12, height: 12, background: '#000', border: `2px solid ${gs.accent}`, borderRadius: '50%' }}/>
            </div>
          </FilterSection>

          <FilterSection title={lang==='ru'?'Авто':'Avto'}>
            {['Chevrolet Cobalt 1.5', 'Lacetti 1.6 SX', 'Spark 1.0'].map((v,i) => (
              <CheckRow key={i} label={v} count={[420, 380, 240][i]} on={i===0}/>
            ))}
          </FilterSection>

          <button style={{ width: '100%', padding: 12, background: gs.accent, color: '#000', fontFamily: gs.display, fontSize: 14, letterSpacing: '1.5px', border: 'none', cursor: 'pointer', marginTop: 8 }}>
            {t.apply.toUpperCase()}
          </button>
          <button style={{ width: '100%', padding: 10, background: 'transparent', color: gs.mute, fontFamily: gs.mono, fontSize: 11, border: `1px solid ${gs.line}`, cursor: 'pointer', marginTop: 6, letterSpacing: '0.1em' }}>
            ⊘  {t.reset.toUpperCase()}
          </button>
        </aside>

        {/* main */}
        <div>
          {/* toolbar */}
          <div style={{
            display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18,
            padding: 12, background: gs.bg2, border: `1px solid ${gs.line}`, borderRadius: 3,
          }}>
            <GLabel>1 240 {lang==='ru'?'РЕЗУЛЬТАТОВ':'NATIJA'}</GLabel>
            <span style={{ width: 1, height: 18, background: gs.line }}/>
            <select style={{
              background: gs.bg, color: gs.text, border: `1px solid ${gs.line}`,
              padding: '7px 10px', fontFamily: gs.mono, fontSize: 11, borderRadius: 2,
            }}>
              {sortOpts.map((s, i) => <option key={i}>{s}</option>)}
            </select>
            <div style={{ flex: 1 }}/>
            <div style={{ display: 'flex', gap: 6 }}>
              {['CHEVROLET COBALT', 'BOSCH', '< 500K'].map((tag, i) => (
                <span key={i} style={{
                  fontFamily: gs.mono, fontSize: 10, letterSpacing: '0.1em',
                  padding: '5px 8px', background: gs.accentDim,
                  color: gs.accent, border: `1px solid ${gs.accent}`, borderRadius: 2,
                }}>{tag}  ✕</span>
              ))}
            </div>
            <span style={{ width: 1, height: 18, background: gs.line }}/>
            <div style={{ display: 'flex', gap: 4 }}>
              {[<svg key="g" width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>,
                <svg key="l" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
              ].map((I, i) => (
                <span key={i} style={{
                  width: 30, height: 30, display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: i === 0 ? gs.accent : 'transparent',
                  color: i === 0 ? '#000' : gs.mute,
                  border: `1px solid ${i === 0 ? gs.accent : gs.line}`, borderRadius: 2, cursor: 'pointer',
                }}>{I}</span>
              ))}
            </div>
          </div>

          {/* grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            {PARTS.slice(0, 9).map(p => <GCard key={p.id} p={p} t={t} f={f}/>)}
          </div>

          {/* pagination */}
          <div style={{ display: 'flex', gap: 6, marginTop: 32, justifyContent: 'center' }}>
            {['‹', '1', '2', '3', '4', '...', '14', '›'].map((p, i) => (
              <span key={i} style={{
                minWidth: 34, height: 34, padding: '0 10px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: gs.mono, fontSize: 12,
                background: p === '2' ? gs.accent : gs.bg2,
                color: p === '2' ? '#000' : gs.text2,
                border: `1px solid ${p === '2' ? gs.accent : gs.line}`,
                borderRadius: 2, cursor: 'pointer',
              }}>{p}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function FilterSection({ title, children, dense }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <div style={{
        fontFamily: gs.mono, fontSize: 10, letterSpacing: '0.16em',
        textTransform: 'uppercase', color: gs.mute,
        paddingBottom: 6, borderBottom: `1px solid ${gs.line}`, marginBottom: 10,
        display: 'flex', justifyContent: 'space-between',
      }}>
        <span>{title}</span><span style={{ color: gs.accent }}>−</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: dense ? 2 : 4 }}>{children}</div>
    </div>
  );
}
function CheckRow({ label, count, on }) {
  return (
    <label style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 0', cursor: 'pointer' }}>
      <span style={{
        width: 14, height: 14, border: `1px solid ${on ? gs.accent : gs.line2}`,
        background: on ? gs.accent : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderRadius: 2,
      }}>{on && <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="#000" strokeWidth="2"><path d="M2 6l3 3 5-6"/></svg>}</span>
      <span style={{ fontSize: 12, color: on ? gs.text : gs.text2, flex: 1 }}>{label}</span>
      <span style={{ fontFamily: gs.mono, fontSize: 10, color: gs.mute }}>{count}</span>
    </label>
  );
}
function FilterInput({ v, l }) {
  return (
    <div style={{ flex: 1, background: gs.bg, border: `1px solid ${gs.line}`, padding: '6px 8px', borderRadius: 2 }}>
      <div style={{ fontFamily: gs.mono, fontSize: 9, color: gs.mute, textTransform: 'uppercase', letterSpacing: '0.1em' }}>{l}</div>
      <div style={{ fontFamily: gs.mono, fontSize: 12, color: gs.text }}>{v}</div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// GARAGE Part Page
// ════════════════════════════════════════════════════════════
function GaragePart({ lang, setLang, density }) {
  const { T, PARTS, fmt } = window.AVTO_DATA;
  const t = T[lang]; const f = fmt(lang);
  const p = PARTS[0]; // BRAKE PADS
  return (
    <div className="ab" style={{ background: gs.bg, color: gs.text, fontFamily: gs.body, minHeight: '100%' }}>
      <GHeader t={t} lang={lang} setLang={setLang} density={density}/>

      <div style={{ padding: '24px 64px' }}>
        <div style={{ display: 'flex', gap: 8, fontFamily: gs.mono, fontSize: 11, color: gs.mute, marginBottom: 24 }}>
          <span>/{t.catalog.toLowerCase()}</span><span>/</span>
          <span>brakes</span><span>/</span>
          <span style={{ color: gs.accent }}>{p.num}</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '460px 1fr 320px', gap: 32 }}>
          {/* gallery */}
          <div>
            <div className="avto-stripe-dark" style={{
              aspectRatio: '1/1', background: `linear-gradient(135deg, ${p.img_color}, #050505)`,
              border: `1px solid ${gs.line}`, position: 'relative',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <GIcon size={200} color="#5A5A5A"/>
              <div style={{ position: 'absolute', top: 12, left: 12, display: 'flex', flexDirection: 'column', gap: 6 }}>
                <span style={{
                  background: '#000', border: `1px solid ${gs.accent}`, color: gs.accent,
                  fontFamily: gs.mono, fontSize: 11, padding: '4px 8px', letterSpacing: '0.05em',
                }}>{p.num}</span>
                <span style={{
                  background: gs.accent, color: '#000',
                  fontFamily: gs.display, fontSize: 14, padding: '4px 8px', letterSpacing: '1.5px',
                }}>−{Math.round((1 - p.price / p.old) * 100)}%</span>
              </div>
              {/* corner crosshairs */}
              {[[8,8,'tl'],[8,8,'tr'],[8,8,'bl'],[8,8,'br']].map(([_,__,k], i) => (
                <div key={k} style={{
                  position: 'absolute',
                  top: i<2?12:'auto', bottom: i>=2?12:'auto',
                  left: i%2===0?12:'auto', right: i%2===1?12:'auto',
                  width: 12, height: 12,
                  borderLeft: i%2===0?`1px solid ${gs.accent}`:'none',
                  borderRight: i%2===1?`1px solid ${gs.accent}`:'none',
                  borderTop: i<2?`1px solid ${gs.accent}`:'none',
                  borderBottom: i>=2?`1px solid ${gs.accent}`:'none',
                }}/>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 6, marginTop: 8 }}>
              {[0,1,2,3,4].map(i => (
                <div key={i} className="avto-stripe-dark" style={{
                  aspectRatio: '1', background: gs.bg2, border: `1px solid ${i===0?gs.accent:gs.line}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}><GIcon size={24} color="#444"/></div>
              ))}
            </div>
          </div>

          {/* info */}
          <div>
            <div style={{ fontFamily: gs.mono, fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase', color: gs.accent, marginBottom: 6 }}>
              {p.brand} · {p.cat}
            </div>
            <h1 style={{ fontFamily: gs.display, fontSize: 44, letterSpacing: '2px', lineHeight: 1.05, margin: '0 0 12px' }}>
              {p.name.toUpperCase()}
            </h1>
            <div style={{ display: 'flex', gap: 8, marginBottom: 24, alignItems: 'center', flexWrap: 'wrap' }}>
              <GBadge tone="ok">● {t.in_stock} · {p.stock} {lang==='ru'?'шт':'dona'}</GBadge>
              <GBadge tone="accent">OEM</GBadge>
              <GBadge>{t.warranty}: 24 {lang==='ru'?'мес':'oy'}</GBadge>
              <span style={{ fontFamily: gs.mono, fontSize: 11, color: gs.text2 }}>
                ★ {p.rating} · {p.reviews} {t.reviews}
              </span>
            </div>

            {/* Specs grid */}
            <div style={{ border: `1px solid ${gs.line}`, marginBottom: 24 }}>
              {[
                [t.part_number, p.num, true],
                [t.manufacturer, p.brand, false],
                [t.country, 'Германия', false],
                [t.weight, '1.84 ' + (lang==='ru'?'кг':'kg'), false],
                [lang==='ru'?'Размеры':"O'lcham", '155×60×17 ' + (lang==='ru'?'мм':'mm'), false],
                [lang==='ru'?'Тип':'Tur', lang==='ru'?'Дисковые':'Diskli', false],
                [lang==='ru'?'Материал':'Material', lang==='ru'?'Керамика':'Keramika', false],
                [t.compatible, p.fits, false],
              ].map(([k, v, mono], i, arr) => (
                <div key={i} style={{
                  display: 'grid', gridTemplateColumns: '180px 1fr',
                  borderBottom: i < arr.length-1 ? `1px solid ${gs.line}` : 'none',
                }}>
                  <div style={{ padding: '12px 14px', background: gs.bg2,
                    fontFamily: gs.mono, fontSize: 10, letterSpacing: '0.12em',
                    textTransform: 'uppercase', color: gs.mute,
                    borderRight: `1px solid ${gs.line}` }}>{k}</div>
                  <div style={{ padding: '12px 14px', fontFamily: mono ? gs.mono : gs.body, fontSize: 13, color: mono ? gs.accent : gs.text }}>{v}</div>
                </div>
              ))}
            </div>

            {/* description */}
            <div style={{ background: gs.card, border: `1px solid ${gs.line}`, padding: 20 }}>
              <GLabel>// {lang==='ru'?'ОПИСАНИЕ':'TAVSIF'}</GLabel>
              <p style={{ fontSize: 13, lineHeight: 1.8, color: gs.text2, margin: '10px 0 0' }}>
                {lang==='ru'
                  ? 'Передние тормозные колодки Bosch с керамическим фрикционным составом для дисковых тормозов. Низкий уровень шума и пылеобразования. Соответствует стандарту ECE R90. Производство Германия. В комплекте: 4 колодки, противоскрипная пластина, датчик износа.'
                  : "Bosch keramik tarkibga ega oldingi tormoz kolodkalari. Past shovqin va chang. ECE R90 standartiga mos. Germaniyada ishlab chiqarilgan. To'plamda: 4 kolodka, plastina, eskirish sensori."}
              </p>
            </div>
          </div>

          {/* purchase rail */}
          <div style={{
            background: gs.card, border: `1px solid ${gs.line}`, padding: 20,
            height: 'fit-content', position: 'sticky', top: 20,
          }}>
            <GLabel>// {t.price.toUpperCase()}</GLabel>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 8 }}>
              <div style={{ fontFamily: gs.display, fontSize: 38, color: gs.accent, letterSpacing: '2px' }}>
                {f(p.price)}
              </div>
            </div>
            <div style={{ fontFamily: gs.mono, fontSize: 12, color: gs.mute, textDecoration: 'line-through' }}>{f(p.old)}</div>
            <div style={{ fontFamily: gs.mono, fontSize: 11, color: gs.ok, marginTop: 4 }}>
              {lang==='ru'?'Экономия':'Tejash'}: {f(p.old - p.price)}
            </div>

            <div style={{ marginTop: 18, display: 'flex', gap: 8, alignItems: 'center', borderTop: `1px solid ${gs.line}`, paddingTop: 14 }}>
              <GLabel>QTY</GLabel>
              <div style={{ display: 'flex', border: `1px solid ${gs.line}`, marginLeft: 'auto' }}>
                <button style={{ width: 30, height: 30, background: gs.bg2, border: 'none', color: gs.text2, cursor: 'pointer' }}>−</button>
                <input value="2" readOnly style={{
                  width: 44, textAlign: 'center', background: gs.bg,
                  border: 'none', borderLeft: `1px solid ${gs.line}`, borderRight: `1px solid ${gs.line}`,
                  fontFamily: gs.mono, color: gs.text, fontSize: 13,
                }}/>
                <button style={{ width: 30, height: 30, background: gs.bg2, border: 'none', color: gs.text2, cursor: 'pointer' }}>+</button>
              </div>
            </div>

            <button style={{
              width: '100%', padding: 14, background: gs.accent, color: '#000',
              fontFamily: gs.display, fontSize: 16, letterSpacing: '2px',
              border: 'none', borderRadius: 2, marginTop: 14, cursor: 'pointer',
            }}>{t.add_to_cart.toUpperCase()}</button>
            <button style={{
              width: '100%', padding: 12, background: 'transparent',
              color: gs.text, fontFamily: gs.body, fontSize: 12, fontWeight: 600,
              letterSpacing: '0.05em', textTransform: 'uppercase',
              border: `1px solid ${gs.line2}`, borderRadius: 2, marginTop: 8, cursor: 'pointer',
            }}>{t.buy_now}</button>

            <div style={{ marginTop: 18, paddingTop: 14, borderTop: `1px solid ${gs.line}`, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['→', t.delivery_24h, lang==='ru'?'Бесплатно от 50 000 ₽':"500 000 so'mdan bepul"],
                ['⊙', t.warranty + ': 24 ' + (lang==='ru'?'месяца':'oy'), lang==='ru'?'Гарантия Bosch':'Bosch kafolati'],
                ['⊞', lang==='ru'?'Возврат 14 дней':'14 kun qaytarish', lang==='ru'?'Без объяснения':'Sababsiz'],
              ].map(([ic, h, sub], i) => (
                <div key={i} style={{ display: 'flex', gap: 10 }}>
                  <span style={{ color: gs.accent, fontFamily: gs.mono, fontSize: 14 }}>{ic}</span>
                  <div>
                    <div style={{ fontSize: 12, color: gs.text, fontWeight: 500 }}>{h}</div>
                    <div style={{ fontFamily: gs.mono, fontSize: 10, color: gs.mute }}>{sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.GarageCatalog = GarageCatalog;
window.GaragePart = GaragePart;
