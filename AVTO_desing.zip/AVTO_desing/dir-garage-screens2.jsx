/* eslint-disable */
/* GARAGE — cart, checkout, search/VIN, login, orders, manager, mobile */

const gs2 = window.garageStyles;
const G2Header = window.GarageHeader;
const G2Label = window.GarageLabel;
const G2Badge = window.GarageBadge;
const G2Icon = window.GaragePartIcon;

// ════════════════════════════════════════════════════════════
// CART  (with quantity controls)
// ════════════════════════════════════════════════════════════
function GarageCart({ lang, setLang, density }) {
  const { T, PARTS, fmt } = window.AVTO_DATA;
  const t = T[lang]; const f = fmt(lang);
  const items = [
    { ...PARTS[0], qty: 2 },
    { ...PARTS[3], qty: 4 },
    { ...PARTS[1], qty: 6 },
  ];
  const total = items.reduce((s, i) => s + i.price * i.qty, 0);
  return (
    <div className="ab" style={{ background: gs2.bg, color: gs2.text, fontFamily: gs2.body, minHeight: '100%' }}>
      <G2Header t={t} lang={lang} setLang={setLang} density={density}/>
      <div style={{ padding: '32px 64px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 24 }}>
          <h1 style={{ fontFamily: gs2.display, fontSize: 48, letterSpacing: '3px', margin: 0 }}>{t.cart.toUpperCase()}</h1>
          <G2Label>{items.length} {lang==='ru'?'ПОЗИЦИИ':'POZITSIYA'} · {items.reduce((s,i)=>s+i.qty,0)} {lang==='ru'?'ШТ':'DONA'}</G2Label>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 24 }}>
          <div style={{ background: gs2.card, border: `1px solid ${gs2.line}` }}>
            <div style={{
              padding: '12px 18px', borderBottom: `1px solid ${gs2.line}`,
              background: gs2.bg2, display: 'grid', gridTemplateColumns: '90px 1fr 130px 110px 130px 40px',
              fontFamily: gs2.mono, fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase', color: gs2.mute,
              gap: 12,
            }}>
              <span></span>
              <span>{lang==='ru'?'ТОВАР':'MAHSULOT'}</span>
              <span style={{ textAlign: 'center' }}>{lang==='ru'?'КОЛ-ВО':'SONI'}</span>
              <span style={{ textAlign: 'right' }}>{t.price.toUpperCase()}</span>
              <span style={{ textAlign: 'right' }}>{lang==='ru'?'СУММА':'JAMI'}</span>
              <span></span>
            </div>
            {items.map((it, i) => (
              <div key={i} style={{
                padding: '14px 18px', borderBottom: i < items.length - 1 ? `1px solid ${gs2.line}` : 'none',
                display: 'grid', gridTemplateColumns: '90px 1fr 130px 110px 130px 40px',
                gap: 12, alignItems: 'center',
              }}>
                <div className="avto-stripe-dark" style={{
                  width: 90, height: 70, background: `linear-gradient(135deg, ${it.img_color}, #0F0F0F)`,
                  border: `1px solid ${gs2.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}><G2Icon size={32} color="#555"/></div>
                <div>
                  <div style={{ fontFamily: gs2.mono, fontSize: 10, color: gs2.accent, marginBottom: 4 }}>{it.num}</div>
                  <div style={{ fontSize: 13, color: gs2.text, fontWeight: 500, marginBottom: 2 }}>{it.name}</div>
                  <div style={{ fontFamily: gs2.mono, fontSize: 10, color: gs2.mute }}>{it.brand} · {it.fits}</div>
                </div>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                  <div style={{ display: 'inline-flex', border: `1px solid ${gs2.line2}`, borderRadius: 2 }}>
                    <button style={{ width: 28, height: 28, background: gs2.bg2, color: gs2.text2, border: 'none', cursor: 'pointer' }}>−</button>
                    <span style={{ width: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: gs2.mono, fontSize: 13, color: gs2.text, borderLeft: `1px solid ${gs2.line2}`, borderRight: `1px solid ${gs2.line2}` }}>{it.qty}</span>
                    <button style={{ width: 28, height: 28, background: gs2.bg2, color: gs2.text2, border: 'none', cursor: 'pointer' }}>+</button>
                  </div>
                </div>
                <div style={{ textAlign: 'right', fontFamily: gs2.mono, fontSize: 12, color: gs2.text2 }}>{f(it.price)}</div>
                <div style={{ textAlign: 'right', fontFamily: gs2.mono, fontSize: 14, color: gs2.accent, fontWeight: 700 }}>{f(it.price * it.qty)}</div>
                <button style={{ width: 28, height: 28, background: 'transparent', border: `1px solid ${gs2.line}`, color: gs2.bad, cursor: 'pointer', fontSize: 14 }}>✕</button>
              </div>
            ))}

            {/* promo + actions */}
            <div style={{ padding: '14px 18px', display: 'flex', gap: 12, alignItems: 'center', background: gs2.bg2 }}>
              <input placeholder={lang==='ru'?'Промокод':'Promokod'} style={{
                flex: 1, background: gs2.bg, border: `1px solid ${gs2.line}`, padding: '8px 12px',
                fontFamily: gs2.mono, fontSize: 12, color: gs2.text, outline: 'none', borderRadius: 2,
              }}/>
              <button style={{
                padding: '8px 14px', background: 'transparent', border: `1px solid ${gs2.line2}`,
                color: gs2.text2, fontFamily: gs2.mono, fontSize: 11, letterSpacing: '0.1em',
                textTransform: 'uppercase', cursor: 'pointer', borderRadius: 2,
              }}>{t.apply}</button>
            </div>
          </div>

          <div style={{ position: 'sticky', top: 20, height: 'fit-content' }}>
            <div style={{ background: gs2.card, border: `1px solid ${gs2.line}`, padding: 22 }}>
              <G2Label>// {t.total.toUpperCase()}</G2Label>
              <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8 }}>
                {[
                  [lang==='ru'?'Подытог':'Sub-jami', f(total), gs2.text2],
                  [t.delivery, lang==='ru'?'Бесплатно':'Bepul', gs2.ok],
                  [lang==='ru'?'Скидка':'Chegirma', '−' + f(124000), gs2.ok],
                ].map(([k, v, c], i) => (
                  <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontFamily: gs2.mono, fontSize: 12 }}>
                    <span style={{ color: gs2.mute }}>{k}</span>
                    <span style={{ color: c }}>{v}</span>
                  </div>
                ))}
              </div>
              <div style={{
                marginTop: 14, paddingTop: 14, borderTop: `2px solid ${gs2.accent}`,
                display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
              }}>
                <G2Label>{t.total.toUpperCase()}</G2Label>
                <span style={{ fontFamily: gs2.display, fontSize: 32, color: gs2.accent, letterSpacing: '2px' }}>{f(total - 124000)}</span>
              </div>
              <button style={{
                width: '100%', padding: 14, marginTop: 14,
                background: gs2.accent, color: '#000',
                fontFamily: gs2.display, fontSize: 16, letterSpacing: '2px', border: 'none', cursor: 'pointer',
              }}>{t.checkout.toUpperCase()}  →</button>
            </div>

            <div style={{ marginTop: 14, padding: 16, border: `1px dashed ${gs2.line2}` }}>
              <G2Label>// {lang==='ru'?'ВКЛЮЧЕНО':'KIRITILGAN'}</G2Label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 10 }}>
                {[
                  lang==='ru'?'Доставка курьером по Ташкенту 24h':"Toshkentda 24 soat yetkazib berish",
                  lang==='ru'?'Гарантия на все позиции':'Barcha pozitsiyalarga kafolat',
                  lang==='ru'?'Возврат в течение 14 дней':'14 kun ichida qaytarish',
                ].map((l, i) => (
                  <div key={i} style={{ display: 'flex', gap: 8, fontFamily: gs2.mono, fontSize: 11, color: gs2.text2 }}>
                    <span style={{ color: gs2.ok }}>✓</span><span>{l}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// CHECKOUT (3-step)
// ════════════════════════════════════════════════════════════
function GarageCheckout({ lang, setLang, density }) {
  const { T, fmt } = window.AVTO_DATA;
  const t = T[lang]; const f = fmt(lang);
  const steps = [t.step_address, t.step_delivery, t.step_payment, t.step_review];
  return (
    <div className="ab" style={{ background: gs2.bg, color: gs2.text, fontFamily: gs2.body, minHeight: '100%' }}>
      <G2Header t={t} lang={lang} setLang={setLang} density={density}/>
      <div style={{ padding: '32px 64px' }}>
        <h1 style={{ fontFamily: gs2.display, fontSize: 44, letterSpacing: '3px', margin: '0 0 24px' }}>
          {t.checkout.toUpperCase()}
        </h1>

        {/* progress */}
        <div style={{ display: 'flex', gap: 0, marginBottom: 32, border: `1px solid ${gs2.line}` }}>
          {steps.map((s, i) => {
            const done = i < 1; const active = i === 1;
            return (
              <div key={i} style={{
                flex: 1, padding: '14px 18px',
                background: active ? gs2.accent : (done ? gs2.bg2 : gs2.card),
                color: active ? '#000' : (done ? gs2.text : gs2.mute),
                borderRight: i < steps.length - 1 ? `1px solid ${gs2.line}` : 'none',
                display: 'flex', alignItems: 'center', gap: 10,
              }}>
                <span style={{
                  width: 26, height: 26, borderRadius: 2,
                  background: active ? '#000' : (done ? gs2.accent : 'transparent'),
                  color: active ? gs2.accent : (done ? '#000' : gs2.mute),
                  border: `1px solid ${active ? '#000' : (done ? gs2.accent : gs2.line2)}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: gs2.display, fontSize: 14,
                }}>{done ? '✓' : (i+1).toString().padStart(2,'0')}</span>
                <div>
                  <div style={{ fontFamily: gs2.mono, fontSize: 9, letterSpacing: '0.16em', textTransform: 'uppercase', opacity: 0.7 }}>STEP {i+1}</div>
                  <div style={{ fontFamily: gs2.display, fontSize: 14, letterSpacing: '1px' }}>{s.toUpperCase()}</div>
                </div>
              </div>
            );
          })}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 24 }}>
          <div>
            <div style={{ background: gs2.card, border: `1px solid ${gs2.line}`, padding: 24 }}>
              <G2Label>// {t.step_delivery.toUpperCase()}</G2Label>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 14 }}>
                {[
                  ['EXPRESS · 24h', lang==='ru'?'Курьер по Ташкенту':"Toshkent kuryeri", '00 ₽', true],
                  ['STANDARD · 3d', lang==='ru'?'По Узбекистану':'Butun mamlakat', '40 000 ₽', false],
                  ['PICKUP · 2h', lang==='ru'?'Самовывоз ул. Фергана-3':"O'zi olib ketish, Fergana-3", '00 ₽', false],
                ].map(([h, s, p, on], i) => (
                  <div key={i} style={{
                    padding: 14, border: `1px solid ${on ? gs2.accent : gs2.line}`,
                    background: on ? 'rgba(255,107,53,0.05)' : gs2.bg2,
                    display: 'flex', alignItems: 'center', gap: 12,
                  }}>
                    <span style={{
                      width: 16, height: 16, borderRadius: '50%', border: `2px solid ${on ? gs2.accent : gs2.line2}`,
                      background: on ? gs2.accent : 'transparent', flexShrink: 0,
                      boxShadow: on ? `inset 0 0 0 3px #000` : 'none',
                    }}/>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontFamily: gs2.display, fontSize: 16, letterSpacing: '1.5px' }}>{h}</div>
                      <div style={{ fontFamily: gs2.mono, fontSize: 11, color: gs2.mute, marginTop: 2 }}>{s}</div>
                    </div>
                    <div style={{ fontFamily: gs2.mono, fontSize: 13, color: on ? gs2.accent : gs2.text2, fontWeight: 700 }}>{p}</div>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ marginTop: 16, background: gs2.card, border: `1px solid ${gs2.line}`, padding: 24 }}>
              <G2Label>// {t.step_address.toUpperCase()}</G2Label>
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 12, marginTop: 14 }}>
                <FormField label={t.address} value="Ташкент, ул. Фергана-3, 14, кв 84"/>
                <FormField label={lang==='ru'?'Индекс':'Indeks'} value="100070" mono/>
                <FormField label={lang==='ru'?'Имя':'Ism'} value="Алишер Каримов"/>
                <FormField label={lang==='ru'?'Телефон':'Telefon'} value="+998 90 123 45 67" mono/>
              </div>
            </div>

            <div style={{ marginTop: 16, background: gs2.card, border: `1px solid ${gs2.line}`, padding: 24 }}>
              <G2Label>// {t.step_payment.toUpperCase()}</G2Label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginTop: 14 }}>
                {[['CARD', '💳'], ['CLICK', 'C'], ['PAYME', 'P'], ['CASH', '₽']].map(([n, ic], i) => (
                  <div key={i} style={{
                    padding: '16px 12px', border: `1px solid ${i===0?gs2.accent:gs2.line}`,
                    background: i===0?'rgba(255,107,53,0.05)':gs2.bg2,
                    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
                  }}>
                    <div style={{ fontFamily: gs2.display, fontSize: 22, color: i===0?gs2.accent:gs2.text2 }}>{ic}</div>
                    <div style={{ fontFamily: gs2.mono, fontSize: 11, letterSpacing: '0.1em' }}>{n}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* order summary */}
          <div style={{ background: gs2.card, border: `1px solid ${gs2.line}`, padding: 22, height: 'fit-content', position: 'sticky', top: 20 }}>
            <G2Label>// {lang==='ru'?'ЗАКАЗ':'BUYURTMA'}</G2Label>
            <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
              {[
                ['BCH-0986AH2851', 2, 974000],
                ['MHL-OC1183', 4, 248000],
                ['NGK-BKR6E-11', 6, 504000],
              ].map(([n, q, p], i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', fontFamily: gs2.mono, fontSize: 11 }}>
                  <span style={{ color: gs2.text2 }}>{n} <span style={{ color: gs2.mute }}>×{q}</span></span>
                  <span style={{ color: gs2.text }}>{f(p)}</span>
                </div>
              ))}
            </div>
            <div style={{ borderTop: `1px solid ${gs2.line}`, marginTop: 14, paddingTop: 14, display: 'flex', flexDirection: 'column', gap: 6, fontFamily: gs2.mono, fontSize: 12 }}>
              <Row k={lang==='ru'?'Сумма':'Summa'} v={f(1726000)}/>
              <Row k={t.delivery} v={lang==='ru'?'Бесплатно':'Bepul'} ok/>
              <Row k={lang==='ru'?'Скидка':'Chegirma'} v={'−' + f(124000)} ok/>
            </div>
            <div style={{ marginTop: 14, paddingTop: 14, borderTop: `2px solid ${gs2.accent}`, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <G2Label>{t.total.toUpperCase()}</G2Label>
              <span style={{ fontFamily: gs2.display, fontSize: 30, color: gs2.accent, letterSpacing: '2px' }}>{f(1602000)}</span>
            </div>
            <button style={{
              width: '100%', padding: 14, marginTop: 14, background: gs2.accent, color: '#000',
              fontFamily: gs2.display, fontSize: 16, letterSpacing: '2px', border: 'none', cursor: 'pointer',
            }}>{(lang==='ru'?'ПОДТВЕРДИТЬ ЗАКАЗ':"BUYURTMANI TASDIQLASH")}  →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
function FormField({ label, value, mono }) {
  return (
    <div style={{ background: gs2.bg, border: `1px solid ${gs2.line}`, padding: '8px 12px', borderRadius: 2 }}>
      <div style={{ fontFamily: gs2.mono, fontSize: 9, color: gs2.mute, textTransform: 'uppercase', letterSpacing: '0.12em', marginBottom: 2 }}>{label}</div>
      <div style={{ fontFamily: mono ? gs2.mono : gs2.body, fontSize: 13, color: gs2.text }}>{value}</div>
    </div>
  );
}
function Row({ k, v, ok }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span style={{ color: gs2.mute }}>{k}</span>
      <span style={{ color: ok ? gs2.ok : gs2.text }}>{v}</span>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// SEARCH + VIN DECODER
// ════════════════════════════════════════════════════════════
function GarageVin({ lang, setLang, density }) {
  const { T, PARTS, fmt } = window.AVTO_DATA;
  const t = T[lang]; const f = fmt(lang);
  const decoded = [
    ['WMI', 'XW8', lang==='ru'?'Узбекистан · UzAuto':"O'zbekiston · UzAuto"],
    ['VDS', 'ZZZ61Z', lang==='ru'?'Cobalt седан 1.5L':'Cobalt sedan 1.5L'],
    ['CHK', 'J', lang==='ru'?'Контрольная цифра':'Tekshirish raqami'],
    ['YEAR', 'G', '2016'],
    ['PLANT', '0', 'Asaka'],
    ['SERIAL', '91284', '#091284'],
  ];
  return (
    <div className="ab" style={{ background: gs2.bg, color: gs2.text, fontFamily: gs2.body, minHeight: '100%' }}>
      <G2Header t={t} lang={lang} setLang={setLang} density={density}/>
      <div style={{ padding: '32px 64px' }}>
        <h1 style={{ fontFamily: gs2.display, fontSize: 56, letterSpacing: '4px', margin: 0 }}>
          {t.vin_decoder.toUpperCase()}
        </h1>
        <G2Label>// {lang==='ru'?'ИДЕНТИФИКАЦИЯ ТРАНСПОРТНОГО СРЕДСТВА':'TRANSPORT VOSITASINI ANIQLASH'}</G2Label>

        {/* VIN block */}
        <div style={{ marginTop: 28, padding: 24, background: gs2.card, border: `1px solid ${gs2.line}` }}>
          <div style={{
            fontFamily: gs2.mono, fontSize: 36, letterSpacing: '0.4em',
            color: gs2.accent, padding: 18, background: '#000',
            border: `1px solid ${gs2.accent}`, borderRadius: 2,
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <span>X W 8 Z Z Z 6 1 Z J G 0 9 1 2 8 4</span>
            <button style={{
              fontFamily: gs2.display, fontSize: 16, letterSpacing: '2px',
              background: gs2.accent, color: '#000', border: 'none',
              padding: '10px 22px', cursor: 'pointer',
            }}>{t.vin_decode.toUpperCase()}</button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 0, marginTop: 16, border: `1px solid ${gs2.line}` }}>
            {decoded.map(([k, code, val], i) => (
              <div key={i} style={{
                padding: 14, borderRight: i < 5 ? `1px solid ${gs2.line}` : 'none', background: gs2.bg2,
              }}>
                <div style={{ fontFamily: gs2.mono, fontSize: 9, letterSpacing: '0.15em', color: gs2.mute }}>{k}</div>
                <div style={{ fontFamily: gs2.display, fontSize: 22, color: gs2.accent, letterSpacing: '2px', margin: '4px 0' }}>{code}</div>
                <div style={{ fontSize: 11, color: gs2.text2 }}>{val}</div>
              </div>
            ))}
          </div>

          {/* Vehicle card */}
          <div style={{
            marginTop: 18, padding: 20, background: gs2.bg2, border: `1px solid ${gs2.line}`,
            display: 'flex', alignItems: 'center', gap: 24,
          }}>
            <div className="avto-stripe-dark" style={{
              width: 180, height: 110, background: 'linear-gradient(135deg, #2A2A2A, #0F0F0F)',
              border: `1px solid ${gs2.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <svg width="100" height="60" viewBox="0 0 200 100" fill="none" stroke="#666" strokeWidth="1.2">
                <path d="M20 70 L40 50 L70 45 L130 45 L160 50 L180 70 L180 80 L20 80 Z"/>
                <circle cx="55" cy="80" r="10"/><circle cx="145" cy="80" r="10"/>
                <path d="M75 45 L80 30 L120 30 L125 45"/>
              </svg>
            </div>
            <div style={{ flex: 1 }}>
              <G2Label style={{ color: gs2.accent }}>VEHICLE IDENTIFIED</G2Label>
              <div style={{ fontFamily: gs2.display, fontSize: 32, letterSpacing: '2px', margin: '6px 0' }}>
                CHEVROLET COBALT 1.5 LT
              </div>
              <div style={{ display: 'flex', gap: 20, fontFamily: gs2.mono, fontSize: 11, color: gs2.text2 }}>
                <span><span style={{ color: gs2.mute }}>YR</span> 2016</span>
                <span><span style={{ color: gs2.mute }}>ENG</span> B15D2 · 1.5L · 105 hp</span>
                <span><span style={{ color: gs2.mute }}>BODY</span> Sedan</span>
                <span><span style={{ color: gs2.mute }}>PLANT</span> Asaka, UZ</span>
              </div>
            </div>
            <button style={{
              padding: '10px 18px', background: 'transparent', border: `1px solid ${gs2.accent}`,
              color: gs2.accent, fontFamily: gs2.mono, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', cursor: 'pointer',
            }}>+ {lang==='ru'?'В ГАРАЖ':"GARAJGA"}</button>
          </div>
        </div>

        {/* Compatible parts */}
        <div style={{ marginTop: 32 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 16 }}>
            <h2 style={{ fontFamily: gs2.display, fontSize: 28, letterSpacing: '2px', margin: 0 }}>
              // {lang==='ru'?'ПОДХОДЯЩИЕ ЗАПЧАСТИ':'MOS EHTIYOT QISMLAR'}
            </h2>
            <G2Label>247 SKU</G2Label>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
            {PARTS.slice(0, 4).map(p => <window.GaragePartCard key={p.id} p={p} t={t} f={f}/>)}
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// LOGIN
// ════════════════════════════════════════════════════════════
function GarageLogin({ lang, setLang, density }) {
  const { T } = window.AVTO_DATA;
  const t = T[lang];
  return (
    <div className="ab" style={{ background: gs2.bg, color: gs2.text, fontFamily: gs2.body, minHeight: '100%', position: 'relative', overflow: 'hidden' }}>
      <window.GarageGrid/>
      <div style={{
        position: 'absolute', right: -200, top: -200, width: 800, height: 800,
        background: 'radial-gradient(circle, rgba(255,107,53,0.15) 0%, transparent 60%)', pointerEvents: 'none',
      }}/>

      <div style={{
        display: 'grid', gridTemplateColumns: '1fr 1fr',
        minHeight: '100vh', position: 'relative', zIndex: 1,
      }}>
        {/* left brand */}
        <div style={{ padding: '64px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', borderRight: `1px solid ${gs2.line}` }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 40, height: 40, background: gs2.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: gs2.display, fontSize: 26, color: '#000' }}>A</div>
            <div style={{ fontFamily: gs2.display, fontSize: 24, letterSpacing: '3px' }}>{t.brand}</div>
          </div>

          <div>
            <G2Label color={gs2.accent} style={{ fontSize: 11 }}>// AUTHORIZED · 24/7 OPS</G2Label>
            <h1 style={{ fontFamily: gs2.display, fontSize: 96, lineHeight: 0.9, letterSpacing: '4px', margin: '14px 0' }}>
              {lang==='ru'?'ВОЙДИ':"KIRING"}<br/>
              <span style={{ color: gs2.accent }}>{lang==='ru'?'В СИСТЕМУ':'TIZIMGA'}</span>
            </h1>
            <div style={{ maxWidth: 380, fontSize: 14, color: gs2.text2, lineHeight: 1.7 }}>
              {lang==='ru'
                ? 'Личный гараж, история заказов, отслеживание поставок, персональные цены для СТО.'
                : "Shaxsiy garaj, buyurtmalar tarixi, yetkazib berishni kuzatish, STO uchun shaxsiy narxlar."}
            </div>
          </div>

          <div style={{ display: 'flex', gap: 24 }}>
            {[['B2C', lang==='ru'?'Розница':'Chakana'], ['B2B', 'СТО / Service'], ['MGR', lang==='ru'?'Менеджер':'Menejer']].map(([n, l], i) => (
              <div key={i}>
                <div style={{ fontFamily: gs2.display, fontSize: 20, letterSpacing: '2px', color: gs2.accent }}>{n}</div>
                <G2Label style={{ fontSize: 9 }}>{l.toUpperCase()}</G2Label>
              </div>
            ))}
          </div>
        </div>

        {/* right form */}
        <div style={{ padding: '64px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ width: '100%', maxWidth: 420 }}>
            <G2Label>// LOG IN · 002</G2Label>
            <h2 style={{ fontFamily: gs2.display, fontSize: 40, letterSpacing: '2px', margin: '8px 0 32px' }}>
              {t.login.toUpperCase()}
            </h2>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <FormFieldFull label={lang==='ru'?'Email или телефон':'Email yoki telefon'} value="alisher@karimov.uz"/>
              <FormFieldFull label={lang==='ru'?'Пароль':'Parol'} value="••••••••••" type="password"/>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 14, fontFamily: gs2.mono, fontSize: 11 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6, color: gs2.text2, cursor: 'pointer' }}>
                <span style={{ width: 14, height: 14, background: gs2.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: 2 }}>
                  <svg width="9" height="9" viewBox="0 0 12 12" fill="none" stroke="#000" strokeWidth="2"><path d="M2 6l3 3 5-6"/></svg>
                </span>
                {lang==='ru'?'Запомнить меня':'Eslab qolish'}
              </label>
              <a style={{ color: gs2.accent, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
                {lang==='ru'?'Забыли пароль?':'Parol unutilganmi?'}
              </a>
            </div>

            <button style={{
              width: '100%', padding: 14, marginTop: 22, background: gs2.accent, color: '#000',
              fontFamily: gs2.display, fontSize: 16, letterSpacing: '2px', border: 'none', cursor: 'pointer',
            }}>{t.login.toUpperCase()}  →</button>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', alignItems: 'center', gap: 12, marginTop: 22 }}>
              <span style={{ height: 1, background: gs2.line }}/>
              <G2Label>{lang==='ru'?'ИЛИ':'YOKI'}</G2Label>
              <span style={{ height: 1, background: gs2.line }}/>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 14 }}>
              {['G  GOOGLE', '⌬  TELEGRAM'].map((b, i) => (
                <button key={i} style={{
                  padding: 12, background: gs2.bg2, color: gs2.text2, border: `1px solid ${gs2.line2}`,
                  fontFamily: gs2.mono, fontSize: 11, letterSpacing: '0.12em', cursor: 'pointer', borderRadius: 2,
                }}>{b}</button>
              ))}
            </div>

            <div style={{ marginTop: 28, fontFamily: gs2.mono, fontSize: 11, color: gs2.mute, textAlign: 'center' }}>
              {lang==='ru'?'Нет аккаунта?':"Hisobingiz yo'qmi?"}{' '}
              <a style={{ color: gs2.accent, letterSpacing: '0.1em', textTransform: 'uppercase' }}>{t.register}</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
function FormFieldFull({ label, value, type }) {
  return (
    <div style={{
      background: gs2.bg2, border: `1px solid ${gs2.line2}`, padding: '10px 14px', borderRadius: 2,
      transition: 'border-color .15s',
    }}>
      <div style={{ fontFamily: gs2.mono, fontSize: 9, color: gs2.mute, letterSpacing: '0.14em', textTransform: 'uppercase' }}>{label}</div>
      <div style={{ fontFamily: gs2.mono, fontSize: 14, color: gs2.text, marginTop: 4, letterSpacing: type === 'password' ? '0.3em' : 0 }}>{value}</div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// ORDERS (buyer)
// ════════════════════════════════════════════════════════════
function GarageOrders({ lang, setLang, density }) {
  const { T, fmt } = window.AVTO_DATA;
  const t = T[lang]; const f = fmt(lang);
  const orders = [
    { id: 'AVT-2026-08412', date: '06.05.2026', items: 5, total: 1602000, st: 'shipping', stl: lang==='ru'?'В пути':'Yo\'lda', ic: '⌖' },
    { id: 'AVT-2026-08398', date: '02.05.2026', items: 2, total: 487000, st: 'delivered', stl: lang==='ru'?'Доставлен':'Yetkazildi', ic: '✓' },
    { id: 'AVT-2026-08311', date: '24.04.2026', items: 8, total: 3240000, st: 'processing', stl: lang==='ru'?'Сборка':'Yig\'ish', ic: '◐' },
    { id: 'AVT-2026-08097', date: '11.04.2026', items: 1, total: 184000, st: 'delivered', stl: lang==='ru'?'Доставлен':'Yetkazildi', ic: '✓' },
  ];
  return (
    <div className="ab" style={{ background: gs2.bg, color: gs2.text, fontFamily: gs2.body, minHeight: '100%' }}>
      <G2Header t={t} lang={lang} setLang={setLang} density={density}/>
      <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr' }}>
        {/* sidebar */}
        <aside style={{ background: gs2.bg2, borderRight: `1px solid ${gs2.line}`, padding: 22, minHeight: 'calc(100vh - 80px)' }}>
          <G2Label>// {lang==='ru'?'КАБИНЕТ':'KABINET'}</G2Label>
          <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 2 }}>
            {[['◇', t.orders, true], ['☼', t.garage, false], ['♡', t.favorites, false], ['↹', t.compare, false], ['◌', t.profile, false], ['→', t.logout, false]].map(([ic, l, on], i) => (
              <a key={i} style={{
                padding: '10px 12px', display: 'flex', alignItems: 'center', gap: 10,
                fontFamily: gs2.mono, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase',
                color: on ? gs2.accent : gs2.text2,
                background: on ? gs2.accentDim : 'transparent',
                borderLeft: `2px solid ${on ? gs2.accent : 'transparent'}`,
              }}><span>{ic}</span>{l}</a>
            ))}
          </div>

          <div style={{ marginTop: 28, padding: 14, background: gs2.bg, border: `1px solid ${gs2.line}` }}>
            <G2Label>// MY GARAGE</G2Label>
            <div style={{ fontFamily: gs2.display, fontSize: 16, letterSpacing: '1.5px', marginTop: 6 }}>
              CHEVROLET COBALT
            </div>
            <div style={{ fontFamily: gs2.mono, fontSize: 10, color: gs2.mute, marginTop: 2 }}>
              2016 · 01 A 234 BB
            </div>
          </div>
        </aside>

        <div style={{ padding: '32px 40px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 20 }}>
            <h1 style={{ fontFamily: gs2.display, fontSize: 36, letterSpacing: '3px', margin: 0 }}>{t.orders.toUpperCase()}</h1>
            <G2Label>14 {lang==='ru'?'ВСЕГО':'JAMI'} · 2 {lang==='ru'?'АКТИВНЫХ':'FAOL'}</G2Label>
          </div>

          {/* tabs */}
          <div style={{ display: 'flex', gap: 0, borderBottom: `1px solid ${gs2.line}`, marginBottom: 18 }}>
            {[lang==='ru'?'Все':'Hammasi', lang==='ru'?'Активные':'Faol', lang==='ru'?'Доставленные':'Yetkazilgan', lang==='ru'?'Отменённые':'Bekor qilingan'].map((tab, i) => (
              <span key={i} style={{
                padding: '12px 18px', fontFamily: gs2.mono, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase',
                color: i === 0 ? gs2.accent : gs2.text2, borderBottom: `2px solid ${i === 0 ? gs2.accent : 'transparent'}`,
                marginBottom: -1, cursor: 'pointer',
              }}>{tab} <span style={{ fontFamily: gs2.mono, color: gs2.mute, marginLeft: 4 }}>{[14, 2, 11, 1][i]}</span></span>
            ))}
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {orders.map((o, i) => {
              const tone = o.st === 'delivered' ? 'ok' : o.st === 'shipping' ? 'accent' : 'warn';
              return (
                <div key={i} style={{
                  background: gs2.card, border: `1px solid ${gs2.line}`,
                  display: 'grid', gridTemplateColumns: '180px 1fr 140px 140px 100px',
                  alignItems: 'center', gap: 12, padding: 18,
                }}>
                  <div>
                    <G2Label>ORDER ID</G2Label>
                    <div style={{ fontFamily: gs2.mono, fontSize: 13, color: gs2.accent, marginTop: 2 }}>{o.id}</div>
                  </div>
                  <div>
                    <G2Label>{o.date} · {o.items} {lang==='ru'?'ПОЗИЦИЙ':'POZITSIYA'}</G2Label>
                    <div style={{ display: 'flex', gap: 4, marginTop: 8 }}>
                      {Array.from({length: Math.min(o.items, 5)}).map((_, j) => (
                        <div key={j} className="avto-stripe-dark" style={{
                          width: 40, height: 32, background: '#1A1A1A',
                          border: `1px solid ${gs2.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
                        }}><G2Icon size={16} color="#555"/></div>
                      ))}
                      {o.items > 5 && <div style={{ width: 40, height: 32, fontFamily: gs2.mono, fontSize: 11, color: gs2.mute, display: 'flex', alignItems: 'center', justifyContent: 'center', border: `1px dashed ${gs2.line}` }}>+{o.items - 5}</div>}
                    </div>
                  </div>
                  <div>
                    <G2Label>{t.total.toUpperCase()}</G2Label>
                    <div style={{ fontFamily: gs2.display, fontSize: 18, color: gs2.accent, letterSpacing: '1.5px', marginTop: 2 }}>{f(o.total)}</div>
                  </div>
                  <G2Badge tone={tone}>{o.ic} {o.stl}</G2Badge>
                  <button style={{
                    padding: '8px 12px', background: 'transparent', color: gs2.text,
                    border: `1px solid ${gs2.line2}`, fontFamily: gs2.mono, fontSize: 10,
                    letterSpacing: '0.12em', textTransform: 'uppercase', cursor: 'pointer',
                  }}>{lang==='ru'?'Открыть':'Ochish'} →</button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════
// MANAGER DASHBOARD
// ════════════════════════════════════════════════════════════
function GarageManager({ lang, setLang, density }) {
  const { T, PARTS, fmt } = window.AVTO_DATA;
  const t = T[lang]; const f = fmt(lang);
  return (
    <div className="ab" style={{ background: gs2.bg, color: gs2.text, fontFamily: gs2.body, minHeight: '100%' }}>
      <G2Header t={t} lang={lang} setLang={setLang} density={density}/>
      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr' }}>
        <aside style={{ background: '#000', borderRight: `1px solid ${gs2.line}`, padding: 18, minHeight: 'calc(100vh - 80px)' }}>
          <div style={{ padding: '8px 10px', marginBottom: 16, background: gs2.accentDim, border: `1px solid ${gs2.accent}` }}>
            <G2Label color={gs2.accent}>MANAGER MODE</G2Label>
            <div style={{ fontFamily: gs2.display, fontSize: 16, letterSpacing: '1.5px', color: gs2.text }}>
              MGR-04
            </div>
          </div>
          <G2Label>// NAV</G2Label>
          <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 2 }}>
            {[['▣', lang==='ru'?'Дашборд':'Boshqaruv', false], ['◇', lang==='ru'?'Товары':'Mahsulotlar', true], ['☰', t.brands, false], ['▥', lang==='ru'?'Категории':'Kategoriya', false], ['◳', t.orders, false], ['☼', lang==='ru'?'Поставки':'Yetkazib berish', false]].map(([ic, l, on], i) => (
              <a key={i} style={{
                padding: '8px 10px', display: 'flex', alignItems: 'center', gap: 10,
                fontFamily: gs2.mono, fontSize: 11, letterSpacing: '0.1em', textTransform: 'uppercase',
                color: on ? '#000' : gs2.text2, background: on ? gs2.accent : 'transparent',
              }}><span>{ic}</span>{l}</a>
            ))}
          </div>
        </aside>

        <div style={{ padding: '24px 32px' }}>
          {/* heading */}
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 18, paddingBottom: 14, borderBottom: `1px solid ${gs2.line}` }}>
            <div>
              <G2Label>// MGR · INVENTORY · 12 480 SKU</G2Label>
              <h1 style={{ fontFamily: gs2.display, fontSize: 32, letterSpacing: '2.5px', margin: '4px 0 0' }}>
                {lang==='ru'?'УПРАВЛЕНИЕ ТОВАРАМИ':'MAHSULOTLARNI BOSHQARISH'}
              </h1>
            </div>
            <button style={{
              padding: '10px 18px', background: gs2.accent, color: '#000',
              fontFamily: gs2.display, fontSize: 14, letterSpacing: '1.5px', border: 'none', cursor: 'pointer',
            }}>+ {lang==='ru'?'НОВЫЙ ТОВАР':'YANGI MAHSULOT'}</button>
          </div>

          {/* stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 22 }}>
            {[
              ['12 480', 'SKU', '+24 ' + (lang==='ru'?'за неделю':'haftada'), gs2.accent],
              ['384', lang==='ru'?'НИЗКИЙ ОСТАТОК':'PAST QOLDIQ', '!! ' + (lang==='ru'?'требует внимания':"e'tibor"), gs2.warn],
              ['8 920', lang==='ru'?'ЗАКАЗЫ':'BUYURTMA', '+12% ' + (lang==='ru'?'месяц':'oy'), gs2.ok],
              ['₽ 142.4M', lang==='ru'?'ОБОРОТ':'AYLANMA', '+8.4% YoY', gs2.text],
            ].map(([n, l, s, c], i) => (
              <div key={i} style={{ background: gs2.card, border: `1px solid ${gs2.line}`, padding: 16, position: 'relative' }}>
                <G2Label>{l}</G2Label>
                <div style={{ fontFamily: gs2.display, fontSize: 30, letterSpacing: '1.5px', color: c, marginTop: 6 }}>{n}</div>
                <div style={{ fontFamily: gs2.mono, fontSize: 10, color: gs2.mute, marginTop: 4 }}>{s}</div>
                <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 2, background: c }}/>
              </div>
            ))}
          </div>

          {/* table */}
          <div style={{ background: gs2.card, border: `1px solid ${gs2.line}` }}>
            <div style={{ padding: 12, borderBottom: `1px solid ${gs2.line}`, background: gs2.bg2, display: 'flex', gap: 8 }}>
              <input placeholder={lang==='ru'?'Поиск по артикулу, названию...':'Artikul, nom...'} style={{
                flex: 1, background: gs2.bg, border: `1px solid ${gs2.line}`,
                padding: '8px 12px', color: gs2.text, fontFamily: gs2.mono, fontSize: 11, outline: 'none', borderRadius: 2,
              }}/>
              {['ALL', 'IN STOCK', 'LOW', 'OUT'].map((f, i) => (
                <button key={i} style={{
                  padding: '8px 12px',
                  background: i === 0 ? gs2.accent : 'transparent',
                  color: i === 0 ? '#000' : gs2.text2,
                  border: `1px solid ${i === 0 ? gs2.accent : gs2.line}`,
                  fontFamily: gs2.mono, fontSize: 10, letterSpacing: '0.1em', cursor: 'pointer', borderRadius: 2,
                }}>{f}</button>
              ))}
            </div>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr style={{ background: gs2.bg2 }}>
                  {['ID', lang==='ru'?'АРТИКУЛ':'ARTIKUL', lang==='ru'?'НАЗВАНИЕ':'NOM', lang==='ru'?'БРЕНД':'BREND', lang==='ru'?'ОСТАТОК':'QOLDIQ', t.price.toUpperCase(), 'STATUS', ''].map((h, i) => (
                    <th key={i} style={{
                      padding: '10px 14px', textAlign: 'left',
                      fontFamily: gs2.mono, fontSize: 9, letterSpacing: '0.16em', color: gs2.mute,
                      borderBottom: `1px solid ${gs2.line}`, fontWeight: 500,
                    }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {PARTS.slice(0, 8).map((p, i) => {
                  const tone = p.stock > 20 ? 'ok' : p.stock > 5 ? 'warn' : 'bad';
                  return (
                    <tr key={i} style={{ borderBottom: `1px solid ${gs2.line}` }}>
                      <td style={{ padding: '10px 14px', fontFamily: gs2.mono, color: gs2.mute }}>#{(1000 + p.id).toString()}</td>
                      <td style={{ padding: '10px 14px', fontFamily: gs2.mono, color: gs2.accent }}>{p.num}</td>
                      <td style={{ padding: '10px 14px', color: gs2.text }}>{p.name}</td>
                      <td style={{ padding: '10px 14px', color: gs2.text2 }}>{p.brand}</td>
                      <td style={{ padding: '10px 14px', fontFamily: gs2.mono, color: gs2.text }}>{p.stock} {lang==='ru'?'шт':'dona'}</td>
                      <td style={{ padding: '10px 14px', fontFamily: gs2.mono, color: gs2.text }}>{f(p.price)}</td>
                      <td style={{ padding: '10px 14px' }}><G2Badge tone={tone}>● {p.stock > 20 ? 'OK' : p.stock > 5 ? 'LOW' : 'CRIT'}</G2Badge></td>
                      <td style={{ padding: '10px 14px', textAlign: 'right' }}>
                        <span style={{ fontFamily: gs2.mono, fontSize: 11, color: gs2.text2, marginRight: 10, cursor: 'pointer' }}>EDIT</span>
                        <span style={{ fontFamily: gs2.mono, fontSize: 11, color: gs2.bad, cursor: 'pointer' }}>✕</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

window.GarageCart = GarageCart;
window.GarageCheckout = GarageCheckout;
window.GarageVin = GarageVin;
window.GarageLogin = GarageLogin;
window.GarageOrders = GarageOrders;
window.GarageManager = GarageManager;
