/* eslint-disable */
/* ─────────────────────────────────────────────────────────────
   AVTO — Direction 01 · GARAGE
   Dark industrial. Bebas Neue display, JetBrains Mono labels.
   Black + #FF6B35 accent. 80px engineering grid.
   Inspired by current dark-theme PHP app — refined.
   ───────────────────────────────────────────────────────────── */

const garageStyles = {
  bg: '#0B0B0B',
  bg2: '#141414',
  card: '#1A1A1A',
  hover: '#222',
  line: '#262626',
  line2: '#333',
  text: '#F2F2F2',
  text2: '#B8B8B8',
  mute: '#6E6E6E',
  accent: '#FF6B35',
  accentDim: 'rgba(255,107,53,0.15)',
  warn: '#F4C542',
  ok: '#6BD968',
  bad: '#E84545',
  display: 'var(--avto-display, "Bebas Neue"), sans-serif',
  mono: '"JetBrains Mono", monospace',
  body: '"Inter", sans-serif',
};

function GarageGrid({ children, dense }) {
  return (
    <div style={{
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none',
      backgroundImage: `
        repeating-linear-gradient(90deg, transparent 0 ${dense?39:79}px, rgba(255,255,255,0.018) ${dense?39:79}px ${dense?40:80}px),
        repeating-linear-gradient(0deg, transparent 0 ${dense?39:79}px, rgba(255,255,255,0.018) ${dense?39:79}px ${dense?40:80}px)
      `,
    }}>{children}</div>
  );
}

const GarageLabel = ({ children, color, style }) => (
  <span style={{
    fontFamily: garageStyles.mono,
    fontSize: 10,
    letterSpacing: '0.18em',
    textTransform: 'uppercase',
    color: color || garageStyles.mute,
    ...style,
  }}>{children}</span>
);

const GarageBadge = ({ children, tone = 'mute', style }) => {
  const palette = {
    mute:   { bg: 'rgba(255,255,255,0.04)', fg: garageStyles.text2, bd: garageStyles.line },
    accent: { bg: garageStyles.accentDim,   fg: garageStyles.accent, bd: garageStyles.accent },
    ok:     { bg: 'rgba(107,217,104,0.1)',  fg: garageStyles.ok,    bd: garageStyles.ok },
    warn:   { bg: 'rgba(244,197,66,0.1)',   fg: garageStyles.warn,  bd: garageStyles.warn },
    bad:    { bg: 'rgba(232,69,69,0.1)',    fg: garageStyles.bad,   bd: garageStyles.bad },
  }[tone];
  return (
    <span style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      padding: '3px 8px',
      fontFamily: garageStyles.mono,
      fontSize: 10,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      background: palette.bg,
      color: palette.fg,
      border: `1px solid ${palette.bd}`,
      borderRadius: 2,
      ...style,
    }}>{children}</span>
  );
};

function GaragePartIcon({ size = 48, color = '#3A3A3A' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" stroke={color} strokeWidth="1">
      <rect x="8" y="22" width="48" height="22" rx="2"/>
      <circle cx="20" cy="33" r="6"/>
      <circle cx="44" cy="33" r="6"/>
      <path d="M14 22V14M50 22V14M8 33h-4M60 33h-4"/>
    </svg>
  );
}

function GaragePlate({ children, w = 80, h = 60 }) {
  return (
    <div className="avto-stripe-dark" style={{
      width: w, height: h,
      background: `linear-gradient(135deg, #1F1F1F, #161616)`,
      border: `1px solid ${garageStyles.line}`,
      borderRadius: 3,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0, position: 'relative', overflow: 'hidden',
    }}>
      <GaragePartIcon size={Math.min(w, h) * 0.55}/>
      {children}
    </div>
  );
}

function GarageBtn({ children, primary, ghost, sm, icon, style, full }) {
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: sm ? '8px 14px' : '12px 22px',
    fontFamily: garageStyles.body,
    fontSize: sm ? 11 : 13,
    fontWeight: 600,
    letterSpacing: '0.04em',
    textTransform: 'uppercase',
    border: '1px solid transparent',
    borderRadius: 3,
    cursor: 'pointer',
    transition: 'all .15s',
    width: full ? '100%' : 'auto',
    ...style,
  };
  if (primary) Object.assign(base, { background: garageStyles.accent, color: '#fff', borderColor: garageStyles.accent });
  else if (ghost) Object.assign(base, { background: 'transparent', color: garageStyles.text2, borderColor: garageStyles.line2 });
  else Object.assign(base, { background: garageStyles.bg2, color: garageStyles.text, borderColor: garageStyles.line });
  return <button style={base}>{icon}{children}</button>;
}

// ─── shared primitives for header ──────────────────────────
function GarageHeader({ t, lang, setLang, density }) {
  const pad = density === 'compact' ? '12px 24px' : '18px 28px';
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 24,
      padding: pad,
      borderBottom: `1px solid ${garageStyles.line}`,
      background: garageStyles.bg,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 32, height: 32, background: garageStyles.accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: garageStyles.display, fontSize: 22, color: '#000',
          letterSpacing: '0.5px',
        }}>A</div>
        <div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1 }}>
          <span style={{ fontFamily: garageStyles.display, fontSize: 20, letterSpacing: '2px', color: garageStyles.text }}>
            {t.brand}
          </span>
          <GarageLabel style={{ fontSize: 9, marginTop: 3 }}>EST. 2018 · TASHKENT</GarageLabel>
        </div>
      </div>

      <nav style={{ display: 'flex', gap: 22, marginLeft: 28 }}>
        {[t.catalog, t.brands, 'VIN', t.sales, t.garage].map((item, i) => (
          <a key={i} style={{
            fontFamily: garageStyles.mono, fontSize: 11, letterSpacing: '0.14em',
            textTransform: 'uppercase', color: i === 0 ? garageStyles.accent : garageStyles.text2,
            textDecoration: 'none', position: 'relative',
          }}>
            {item}
            {i === 0 && <span style={{ position: 'absolute', bottom: -22, left: 0, right: 0, height: 2, background: garageStyles.accent }}/>}
          </a>
        ))}
      </nav>

      <div style={{ flex: 1 }}/>

      <div style={{
        display: 'flex', alignItems: 'center',
        background: garageStyles.bg2, border: `1px solid ${garageStyles.line}`,
        borderRadius: 3, padding: '6px 8px 6px 12px', minWidth: 320, gap: 8,
      }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={garageStyles.mute} strokeWidth="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>
        <span style={{ fontFamily: garageStyles.mono, fontSize: 11, color: garageStyles.mute }}>
          {t.search_ph.slice(0, 28)}…
        </span>
        <kbd style={{
          marginLeft: 'auto', fontFamily: garageStyles.mono, fontSize: 9,
          color: garageStyles.mute, border: `1px solid ${garageStyles.line2}`, borderRadius: 2,
          padding: '2px 5px',
        }}>⌘K</kbd>
      </div>

      <div style={{ display: 'flex', gap: 6 }}>
        {['ru', 'uz'].map(L => (
          <button key={L} onClick={() => setLang(L)} style={{
            fontFamily: garageStyles.mono, fontSize: 10, letterSpacing: '0.1em',
            padding: '6px 8px', background: lang === L ? garageStyles.accent : 'transparent',
            color: lang === L ? '#000' : garageStyles.mute,
            border: `1px solid ${lang === L ? garageStyles.accent : garageStyles.line}`,
            borderRadius: 2, cursor: 'pointer', textTransform: 'uppercase',
          }}>{L}</button>
        ))}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <span style={{ position: 'relative', color: garageStyles.text2 }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l8.84 8.84 8.84-8.84a5.5 5.5 0 000-7.78z"/></svg>
          <span style={{ position: 'absolute', top: -5, right: -7, fontFamily: garageStyles.mono, fontSize: 9, background: garageStyles.accent, color: '#000', borderRadius: 2, padding: '0 4px' }}>3</span>
        </span>
        <span style={{ position: 'relative', color: garageStyles.accent }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"/><path d="M3 6h18M16 10a4 4 0 01-8 0"/></svg>
          <span style={{ position: 'absolute', top: -5, right: -7, fontFamily: garageStyles.mono, fontSize: 9, background: garageStyles.accent, color: '#000', borderRadius: 2, padding: '0 4px' }}>2</span>
        </span>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════
// SCREEN 01 — GARAGE Home (desktop)
// ════════════════════════════════════════════════════════════════
function GarageHome({ lang, setLang, density }) {
  const { T, BRANDS, PARTS, fmt } = window.AVTO_DATA;
  const t = T[lang]; const f = fmt(lang);
  return (
    <div className="ab" style={{
      width: '100%', minHeight: '100%',
      background: garageStyles.bg, color: garageStyles.text,
      fontFamily: garageStyles.body,
    }}>
      <GarageHeader t={t} lang={lang} setLang={setLang} density={density}/>

      {/* Hero */}
      <div style={{ position: 'relative', overflow: 'hidden', borderBottom: `1px solid ${garageStyles.line}` }}>
        <GarageGrid/>
        <div style={{
          position: 'absolute', right: -80, top: -40, width: 720, height: 720,
          background: 'radial-gradient(circle, rgba(255,107,53,0.22) 0%, transparent 60%)',
          pointerEvents: 'none',
        }}/>
        <div style={{ position: 'relative', padding: '72px 64px 80px', maxWidth: 1440 }}>
          <GarageLabel color={garageStyles.accent} style={{ fontSize: 11 }}>
            {t.hero_eyebrow}
          </GarageLabel>
          <h1 style={{
            fontFamily: garageStyles.display, fontSize: 132, lineHeight: 0.88,
            letterSpacing: '4px', margin: '20px 0 8px', color: garageStyles.text,
          }}>
            {t.hero_title_a}<br/>
            <span style={{ color: garageStyles.accent }}>{t.hero_title_b}</span>
          </h1>
          <p style={{ maxWidth: 540, fontSize: 14, lineHeight: 1.7, color: garageStyles.text2, margin: '24px 0 36px' }}>
            {t.hero_sub}
          </p>

          {/* search */}
          <div style={{
            display: 'flex', gap: 0, maxWidth: 720,
            background: garageStyles.bg2, border: `1px solid ${garageStyles.line2}`, borderRadius: 4,
            padding: 8, alignItems: 'stretch',
          }}>
            <div style={{ display: 'flex', borderRight: `1px solid ${garageStyles.line}` }}>
              {['VIN', t.part_number.toUpperCase(), 'OEM'].map((m, i) => (
                <button key={i} style={{
                  padding: '10px 16px', fontFamily: garageStyles.mono, fontSize: 11,
                  letterSpacing: '0.1em',
                  background: i === 0 ? garageStyles.accent : 'transparent',
                  color: i === 0 ? '#000' : garageStyles.text2,
                  border: 'none', cursor: 'pointer',
                }}>{m}</button>
              ))}
            </div>
            <input style={{
              flex: 1, background: 'transparent', border: 'none', padding: '0 16px',
              color: garageStyles.text, fontFamily: garageStyles.mono, fontSize: 13, outline: 'none',
            }} placeholder={t.vin_ph} defaultValue="XW8ZZZ61ZJG091284"/>
            <button style={{
              padding: '0 28px', fontFamily: garageStyles.display, fontSize: 18, letterSpacing: '2px',
              background: garageStyles.accent, color: '#000', border: 'none', cursor: 'pointer',
            }}>{t.search.toUpperCase()}</button>
          </div>

          <div style={{ display: 'flex', gap: 28, marginTop: 28 }}>
            {[
              ['12 480', t.part_number],
              ['86', t.brands],
              ['24h', t.delivery_24h.split(' ')[0]],
              ['98.4%', 'OEM'],
            ].map(([n, l], i) => (
              <div key={i} style={{ borderLeft: `1px solid ${garageStyles.line2}`, paddingLeft: 14 }}>
                <div style={{ fontFamily: garageStyles.display, fontSize: 30, letterSpacing: '2px', color: garageStyles.text }}>{n}</div>
                <GarageLabel style={{ fontSize: 9 }}>{l}</GarageLabel>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Categories rail */}
      <div style={{ padding: '56px 64px', borderBottom: `1px solid ${garageStyles.line}` }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 28 }}>
          <h2 style={{ fontFamily: garageStyles.display, fontSize: 36, letterSpacing: '3px', margin: 0 }}>
            // {t.categories_h.toUpperCase()}
          </h2>
          <GarageLabel>{t.categories.length} GROUPS · 9 480 SKU</GarageLabel>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 0, border: `1px solid ${garageStyles.line}` }}>
          {t.categories.map(([name, slug, count], i) => (
            <div key={slug} style={{
              padding: 24, borderRight: i % 4 !== 3 ? `1px solid ${garageStyles.line}` : 'none',
              borderBottom: i < 4 ? `1px solid ${garageStyles.line}` : 'none',
              background: garageStyles.bg2, position: 'relative',
              minHeight: 140, display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <GarageLabel style={{ color: garageStyles.accent }}>0{i+1}</GarageLabel>
                <GarageLabel>{count}</GarageLabel>
              </div>
              <div>
                <div style={{ fontFamily: garageStyles.display, fontSize: 24, letterSpacing: '1.5px', color: garageStyles.text }}>
                  {name.toUpperCase()}
                </div>
                <GarageLabel style={{ marginTop: 6 }}>→ {slug.toUpperCase()}</GarageLabel>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Featured parts */}
      <div style={{ padding: '56px 64px', borderBottom: `1px solid ${garageStyles.line}` }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 28 }}>
          <h2 style={{ fontFamily: garageStyles.display, fontSize: 36, letterSpacing: '3px', margin: 0 }}>
            // {t.featured_h.toUpperCase()}
          </h2>
          <div style={{ display: 'flex', gap: 8 }}>
            <GarageBadge tone="accent">LIVE</GarageBadge>
            <GarageLabel>UPDATED 14:32</GarageLabel>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
          {PARTS.slice(0, 4).map(p => <GaragePartCard key={p.id} p={p} t={t} f={f}/>)}
        </div>
      </div>

      {/* Brands strip */}
      <div style={{ padding: '40px 64px', borderBottom: `1px solid ${garageStyles.line}` }}>
        <GarageLabel>// {t.brands_h.toUpperCase()}</GarageLabel>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 12, marginTop: 16 }}>
          {BRANDS.slice(0, 6).map(b => (
            <div key={b.name} style={{
              padding: '20px 16px', border: `1px solid ${garageStyles.line}`,
              background: garageStyles.bg2,
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <div style={{
                width: 44, height: 44, background: '#000', border: `1px solid ${garageStyles.accent}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: garageStyles.display, fontSize: 18, color: garageStyles.accent,
              }}>{b.logo}</div>
              <div>
                <div style={{ fontFamily: garageStyles.display, fontSize: 16, letterSpacing: '1px' }}>{b.name.toUpperCase()}</div>
                <GarageLabel style={{ fontSize: 9 }}>{b.country} · ORIG.</GarageLabel>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div style={{ padding: '40px 64px 32px', background: '#050505' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div style={{ fontFamily: garageStyles.display, fontSize: 56, letterSpacing: '3px', color: garageStyles.text }}>
              {t.brand}
            </div>
            <GarageLabel style={{ marginTop: 4 }}>// {t.tagline.toUpperCase()}</GarageLabel>
          </div>
          <div style={{ textAlign: 'right' }}>
            <GarageLabel>{t.free_ship.toUpperCase()}</GarageLabel>
            <div style={{ fontFamily: garageStyles.mono, fontSize: 11, color: garageStyles.text2, marginTop: 6 }}>
              {t.payment_methods}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Garage part card (used by home, catalog) ──────────────
function GaragePartCard({ p, t, f }) {
  const stockTone = p.stock > 20 ? 'ok' : p.stock > 5 ? 'warn' : 'bad';
  const stockLabel = p.stock > 20 ? t.in_stock : p.stock > 5 ? t.few_left : (p.stock > 0 ? t.few_left : t.out_of_stock);
  return (
    <div style={{
      background: garageStyles.card, border: `1px solid ${garageStyles.line}`,
      borderRadius: 3, display: 'flex', flexDirection: 'column', position: 'relative',
    }}>
      <div className="avto-stripe-dark" style={{
        aspectRatio: '4/3', background: `linear-gradient(135deg, ${p.img_color}, #0F0F0F)`,
        position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center',
        borderBottom: `1px solid ${garageStyles.line}`,
      }}>
        <GaragePartIcon size={64} color="#444"/>
        <span style={{
          position: 'absolute', top: 10, left: 10, background: '#000',
          border: `1px solid ${garageStyles.accent}`, color: garageStyles.accent,
          fontFamily: garageStyles.mono, fontSize: 10, padding: '3px 7px', borderRadius: 2,
          letterSpacing: '0.05em',
        }}>{p.num}</span>
        {p.old && (
          <span style={{
            position: 'absolute', top: 10, right: 10, background: garageStyles.accent,
            color: '#000', fontFamily: garageStyles.display, fontSize: 14, padding: '4px 8px',
            borderRadius: 2, letterSpacing: '1px',
          }}>−{Math.round((1 - p.price / p.old) * 100)}%</span>
        )}
        <button style={{
          position: 'absolute', bottom: 10, right: 10,
          width: 28, height: 28, background: 'rgba(0,0,0,0.7)',
          border: `1px solid ${garageStyles.line2}`, borderRadius: 2, cursor: 'pointer',
          color: garageStyles.text2, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l8.84 8.84 8.84-8.84a5.5 5.5 0 000-7.78z"/></svg>
        </button>
      </div>
      <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 6, flex: 1 }}>
        <GarageLabel style={{ fontSize: 9 }}>{p.brand.toUpperCase()} · {p.cat.toUpperCase()}</GarageLabel>
        <div style={{ fontSize: 13, lineHeight: 1.4, color: garageStyles.text, fontWeight: 500, minHeight: 36 }}>
          {p.name}
        </div>
        <div style={{ fontFamily: garageStyles.mono, fontSize: 10, color: garageStyles.mute }}>
          {p.fits}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 'auto', paddingTop: 10, borderTop: `1px solid ${garageStyles.line}` }}>
          <div>
            <div style={{ fontFamily: garageStyles.mono, fontSize: 16, color: garageStyles.accent, fontWeight: 700 }}>{f(p.price)}</div>
            {p.old && <div style={{ fontFamily: garageStyles.mono, fontSize: 10, color: garageStyles.mute, textDecoration: 'line-through' }}>{f(p.old)}</div>}
          </div>
          <GarageBadge tone={stockTone}>{stockLabel}</GarageBadge>
        </div>
        <button style={{
          marginTop: 6, padding: '10px', background: garageStyles.accent, color: '#000',
          fontFamily: garageStyles.display, fontSize: 14, letterSpacing: '1.5px',
          border: 'none', borderRadius: 2, cursor: 'pointer', width: '100%',
        }}>{t.add_to_cart.toUpperCase()}</button>
      </div>
    </div>
  );
}

window.GarageHome = GarageHome;
window.GaragePartCard = GaragePartCard;
window.GarageHeader = GarageHeader;
window.GarageLabel = GarageLabel;
window.GarageBadge = GarageBadge;
window.GaragePlate = GaragePlate;
window.GaragePartIcon = GaragePartIcon;
window.GarageBtn = GarageBtn;
window.GarageGrid = GarageGrid;
window.garageStyles = garageStyles;
